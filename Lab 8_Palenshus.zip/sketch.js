
var img1;
var img2;
var gif1;

function preload() {

	img1 = loadImage("album1.jpg");
	img2 = loadImage("album3.png");
    gif1 = loadImage("dance1.gif");

}

function setup () {

	createCanvas(400, 400);

}

function draw () {

	image(img1, -120, 0);

	image(img2, 1, mouseY, 120, 60);
    
    image(gif1, mouseX, mouseY, 200, 300);
  
    textSize(32);
    textFont('Gotham');
    fill(0);
    stroke(10);
    text('Fallen to the fire', 20, 30);
}

