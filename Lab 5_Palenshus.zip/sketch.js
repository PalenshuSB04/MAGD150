function setup() {
  createCanvas(400, 400);
}
var blank = false;
var on = false;
var channel = false;
var d = 20;

function draw() {
  background(220);
  
  rectMode(RADIUS);
  fill(255, 200, 100);
  rect(200, 200, 120, 120);
  rectMode(CENTER);
  fill(50);
  rect(200, 200, 150, 150);
  
  ellipseMode(RADIUS);
  fill(255);
  ellipse(297, 200, 20, 20); 
  ellipseMode(CENTER);
  fill(100);
  ellipse(297, 200, d, d); 
  
  fill(255, 50, 50);
  rect(297, 160, d, d);
  
  fill(150);
  ellipse(297, 240, d, d);
  
  if(blank) {
    fill(100);
    rect(200, 200, 150, 150);
  } else {
    if(on) {
      fill(200);
      rect(200,200, 150, 150);
    } else {
      if(channel){
        fill(50, 50, 250);
        rect(200, 200, 150, 150);
      }
    }
  }
}

function mouseClicked(){
  if (dist(mouseX, mouseY, 297, 200) < d/2){
    on = !on;
  }
  if (dist(mouseX, mouseY, 297, 160) < d/2){
    blank = !blank;
  }
}

function keyPressed(){
  if (dist(mouseX, mouseY, 297, 240) < d/2){
    channel = !channel;
  }
}