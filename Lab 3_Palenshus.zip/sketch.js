function setup() {
  createCanvas(400, 400);
  frameRate(30);
  background(220);
}

function draw() {
  fill(255, 100, 100);
  noStroke();
  square(mouseX, mouseY, 20, 20);
  fill(0);
  line(mouseX, mouseY, pmouseX, pmouseY);
  
}

function mousePressed() {
  background(100, 255, 100);
}